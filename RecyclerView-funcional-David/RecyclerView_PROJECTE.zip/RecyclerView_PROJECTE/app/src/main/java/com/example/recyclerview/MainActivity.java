package com.example.recyclerview;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<ExampleItem> mExampleList;

    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private Button buttonInsert;
    private Button buttonRemove;
    private EditText editTextInsert;
    private EditText editTextRemove;
    FloatingActionButton button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (FloatingActionButton) findViewById(R.id.fab);
        createExampleList();
        buildRecyclerView();
        setButtons();

    }


    public void insertItem(int position) {
        mExampleList.add(position, new ExampleItem(R.drawable.newnew, "New Item At Position" + position, "This is Line 2"));
        mAdapter.notifyItemInserted(position);
        insertarToastcreado();
    }

    public void removeItem(int position) {
        mExampleList.remove(position);
        mAdapter.notifyItemRemoved(position);
        insertarToastborrado();
    }

    public void changeItem(int position, String text) {
        mExampleList.get(position).changeText1(text);
        mAdapter.notifyItemChanged(position);

        if ((position == 1) || (position == 3) || (position ==5) || (position ==7)) {
             Snack(position);
        }else{
            insertarToastcambio(position);
        }
            }


    public void createExampleList() {
        mExampleList = new ArrayList<>();
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 1", "Line 2"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 3", "Line 4"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 5", "Line 6"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 7", "Line 8"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 9", "Line 10"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 11", "Line 12"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 13", "Line 14"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 15", "Line 16"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 17", "Line 18"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 19", "Line 20"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 21", "Line 22"));
        mExampleList.add(new ExampleItem(R.drawable.matrix, "Line 23", "Line 24"));

    }

    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                changeItem(position, "Clicked");
            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });
    }

    public void setButtons() {
        buttonInsert = findViewById(R.id.button_insert);
        buttonRemove = findViewById(R.id.button_remove);
        editTextInsert = findViewById(R.id.edittext_insert);
        editTextRemove = findViewById(R.id.edittext_remove);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = Integer.parseInt(editTextInsert.getText().toString());
                insertItem(position);

            }
        });

        buttonRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = Integer.parseInt(editTextRemove.getText().toString());
                removeItem(position);

            }
        });

        //   s   n   a   c  k    B   A   R



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Esto es un SNACKBAR", Snackbar.LENGTH_LONG)
                        .setAction("Cerrar", cerrar)
                        .show();
            }

        });
    }

    public View.OnClickListener cerrar = new View.OnClickListener() {
        public void onClick(View v) {
            finish();

        }
    };

    public void insertarToastborrado(){
        Toast.makeText(this,"elemento BORRADO",Toast.LENGTH_SHORT).show();

    }
    public void insertarToastcreado(){
        Toast.makeText(this,"elemento CREADO",Toast.LENGTH_SHORT).show();

    }
    public void insertarToastcambio(int position){
        Toast.makeText(this,"elemento CLICKADO Nº " + position ,Toast.LENGTH_SHORT).show();

    }
    public void Snack(int position) {
        Snackbar.make(findViewById(android.R.id.content), "HAS CLICKADO EL " + position +" elemento", Snackbar.LENGTH_LONG)
                .setAction("Cerrar", cerrar)
                .show();
    }

}





